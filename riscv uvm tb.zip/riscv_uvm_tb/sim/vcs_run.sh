#!/usr/bin/env bash
# =============================================================================
# sim/vcs_run.sh — VCS compile + simulate
# =============================================================================
# Usage:
#   bash vcs_run.sh                          # default: riscv_all_test
#   bash vcs_run.sh riscv_rtype_test
#   bash vcs_run.sh riscv_branch_test
# =============================================================================
set -e
cd "$(dirname "$0")"

TEST=${1:-riscv_all_test}
RTL=../rtl
TB=../tb
OUT=./vcs_out
mkdir -p "$OUT"

echo "========================================"
echo " VCS Compile + Simulate"
echo " Test: $TEST"
echo "========================================"

# ── Compile ───────────────────────────────────────────────────
vcs -full64 -sverilog \
    -ntb_opts uvm-1.2 \
    -timescale=1ns/1ps \
    +incdir+"$TB" \
    -f - << FLIST
$RTL/alu.sv
$RTL/alu_ctrl.sv
$RTL/control.sv
$RTL/regfile.sv
$RTL/imm_gen.sv
$RTL/forwarding_unit.sv
$RTL/hdu.sv
$RTL/branch_predictor.sv
$RTL/riscv_pipeline.sv
$TB/riscv_if.sv
$TB/riscv_tb_pkg.sv
$TB/tb_top.sv
FLIST

# ── Simulate ──────────────────────────────────────────────────
./simv \
    +UVM_TESTNAME="$TEST" \
    +UVM_VERBOSITY=UVM_MEDIUM \
    -l "$OUT/${TEST}.log" \
    +vcs+lic+wait

echo ""
echo "Log: $OUT/${TEST}.log"
