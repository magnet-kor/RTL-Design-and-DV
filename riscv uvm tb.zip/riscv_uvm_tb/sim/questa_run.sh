#!/usr/bin/env bash
# =============================================================================
# sim/questa_run.sh — Questa (ModelSim) compile + simulate
# =============================================================================
# Usage:
#   bash questa_run.sh                       # default: riscv_all_test
#   bash questa_run.sh riscv_rtype_test
# =============================================================================
set -e
cd "$(dirname "$0")"

TEST=${1:-riscv_all_test}
RTL=../rtl
TB=../tb
LIB=riscv_work
mkdir -p questa_out

echo "========================================"
echo " Questa Compile + Simulate"
echo " Test: $TEST"
echo "========================================"

# ── Create or refresh work library ────────────────────────────
vlib $LIB
vmap work $LIB

# ── Compile RTL ───────────────────────────────────────────────
vlog -sv -work $LIB \
    +incdir+"$TB" \
    "$RTL/alu.sv"              \
    "$RTL/alu_ctrl.sv"         \
    "$RTL/control.sv"          \
    "$RTL/regfile.sv"          \
    "$RTL/imm_gen.sv"          \
    "$RTL/forwarding_unit.sv"  \
    "$RTL/hdu.sv"              \
    "$RTL/branch_predictor.sv" \
    "$RTL/riscv_pipeline.sv"

# ── Compile TB ────────────────────────────────────────────────
vlog -sv -work $LIB \
    -L mtiUvm \
    +incdir+"$TB" \
    "$TB/riscv_if.sv"     \
    "$TB/riscv_tb_pkg.sv" \
    "$TB/tb_top.sv"

# ── Simulate ──────────────────────────────────────────────────
vsim -batch -work $LIB \
    -L mtiUvm \
    tb_top \
    +UVM_TESTNAME="$TEST" \
    +UVM_VERBOSITY=UVM_MEDIUM \
    -do "run -all; quit -f" \
    -logfile "questa_out/${TEST}.log"

echo ""
echo "Log: questa_out/${TEST}.log"
