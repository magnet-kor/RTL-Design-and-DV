// =============================================================================
// riscv_monitor.sv — UVM Monitor
// =============================================================================
// Triggered by driver's ap_done write (via TLM FIFO).
// Samples the architectural register file via uvm_hdl_read (backdoor).
// Forwards the completed transaction (with obs_regs filled) to:
//   - scoreboard (ap_sb)
//   - coverage collector (ap_cov)
// =============================================================================

`ifndef RISCV_MONITOR_SV
`define RISCV_MONITOR_SV

class riscv_monitor extends uvm_monitor;

    `uvm_component_utils(riscv_monitor)

    // Receive "run done" notification from driver
    uvm_tlm_analysis_fifo #(riscv_seq_item) fifo_done;

    // Forward observed transactions
    uvm_analysis_port #(riscv_seq_item) ap_sb;    // → scoreboard
    uvm_analysis_port #(riscv_seq_item) ap_cov;   // → coverage

    string hdl_root;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        fifo_done = new("fifo_done", this);
        ap_sb     = new("ap_sb",  this);
        ap_cov    = new("ap_cov", this);

        if (!uvm_config_db #(string)::get(this, "", "hdl_root", hdl_root))
            hdl_root = "tb_top.dut";
    endfunction

    task run_phase(uvm_phase phase);
        riscv_seq_item item;
        forever begin
            fifo_done.get(item);
            sample_regfile(item);
            ap_sb.write(item);
            ap_cov.write(item);
        end
    endtask

    // ── Backdoor: read all 32 architectural registers ─────────
    task automatic sample_regfile(riscv_seq_item item);
        string path;
        uvm_hdl_data_t rdata;

        item.obs_regs[0] = 32'b0;  // x0 hardwired zero

        for (int r = 1; r < 32; r++) begin
            // HDL path into the register file array
            // Adjust if regfile is registered differently in synthesis
            path = $sformatf("%s.u_rf.regs[%0d]", hdl_root, r);
            if (uvm_hdl_read(path, rdata))
                item.obs_regs[r] = rdata[31:0];
            else
                `uvm_error("MON", $sformatf("uvm_hdl_read failed: %s", path))
        end

        `uvm_info("MON",
            $sformatf("[%s] Sampled regs: x1=0x%08x x2=0x%08x x3=0x%08x",
                      item.tag,
                      item.obs_regs[1],
                      item.obs_regs[2],
                      item.obs_regs[3]),
            UVM_HIGH)
    endtask

endclass : riscv_monitor

`endif // RISCV_MONITOR_SV
