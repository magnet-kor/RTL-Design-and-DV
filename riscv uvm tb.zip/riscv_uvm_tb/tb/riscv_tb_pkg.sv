// =============================================================================
// riscv_tb_pkg.sv — Testbench Package
// =============================================================================
// Compile this package once; all TB classes are included in dependency order.
//
// Commercial tool compile:
//   VCS:     vcs -sverilog -ntb_opts uvm-1.2 riscv_tb_pkg.sv
//   Questa:  vlog -sv -L mtiUvm riscv_tb_pkg.sv
//   Xcelium: xrun -uvm riscv_tb_pkg.sv
// =============================================================================

package riscv_tb_pkg;

    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // 1. Transaction
    `include "riscv_seq_item.sv"

    // 2. Reference model
    `include "riscv_isa_model.sv"

    // 3. Testbench components
    `include "riscv_driver.sv"
    `include "riscv_monitor.sv"
    `include "riscv_scoreboard.sv"
    `include "riscv_coverage.sv"

    // 4. Sequences
    `include "riscv_sequences.sv"

    // 5. Agent + Environment
    `include "riscv_agent_env.sv"

    // 6. Tests
    `include "riscv_tests.sv"

endpackage : riscv_tb_pkg
