// =============================================================================
// riscv_sequences.sv — Test Sequences
// =============================================================================
// Each sequence builds a program, sets check_mask, and sends one seq_item.
// Expected values are cross-checked independently by the scoreboard's
// ISA reference model — not pre-computed here.
//
//   riscv_rtype_seq      R-type arithmetic (ADD SUB AND OR XOR SLL SRL SLT)
//   riscv_load_use_seq   Load-use hazard  (SW → LW → dependent ADD)
//   riscv_branch_seq     BEQ taken, BEQ not-taken, BNE taken
//   riscv_fwd_chain_seq  3-deep EX-EX forwarding chain
//   riscv_loop_seq       Sum 1..10 (warms branch predictor, checks BGE)
//   riscv_jal_seq        JAL: link register + skip + target execution
// =============================================================================

`ifndef RISCV_SEQUENCES_SV
`define RISCV_SEQUENCES_SV

// ── Encoding helpers (module-level functions not allowed in SV packages,
//    so encode inline or use a static utility class) ──────────────────────

// Opcode constants (package-level: portable across all commercial tools)
localparam logic [6:0] ENC_OP     = 7'b0110011;
localparam logic [6:0] ENC_OP_IMM = 7'b0010011;
localparam logic [6:0] ENC_LOAD   = 7'b0000011;
localparam logic [31:0] ENC_NOP   = 32'h0000_0013;

class riscv_enc;
    // Instruction encoding helpers — all static functions, no data members
    // (avoids static member initialisation portability issues)
    static function logic [31:0] R(
        logic [6:0] f7, logic [4:0] rs2, rs1,
        logic [2:0] f3, logic [4:0] rd, logic [6:0] op);
        return {f7, rs2, rs1, f3, rd, op};
    endfunction
    static function logic [31:0] I(
        logic [11:0] imm, logic [4:0] rs1,
        logic [2:0]  f3,  logic [4:0] rd, logic [6:0] op);
        return {imm, rs1, f3, rd, op};
    endfunction
    static function logic [31:0] S(
        logic [11:0] imm, logic [4:0] rs2, rs1, logic [2:0] f3);
        return {imm[11:5], rs2, rs1, f3, imm[4:0], 7'b0100011};
    endfunction
    static function logic [31:0] B(
        logic [12:0] imm, logic [4:0] rs1, rs2, logic [2:0] f3);
        return {imm[12], imm[10:5], rs2, rs1, f3,
                imm[4:1], imm[11], 7'b1100011};
    endfunction
    static function logic [31:0] J(logic [20:0] imm, logic [4:0] rd);
        return {imm[20], imm[10:1], imm[11], imm[19:12], rd, 7'b1101111};
    endfunction
endclass

// =============================================================================
// riscv_rtype_seq — R-type arithmetic
// =============================================================================
class riscv_rtype_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_rtype_seq)

    function new(string name = "riscv_rtype_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "rtype";
        item.run_cycles = 25;
        item.check_mask = 32'hFF << 1;  // check x1..x8

        // x1=10, x2=3
        // x3=ADD=13, x4=SUB=7, x5=AND=2, x6=OR=11, x7=XOR=9, x8=SLL=80
        item.program = '{
            riscv_enc::I(12'd10, 5'd0, 3'b000, 5'd1, ENC_OP_IMM), // x1=10
            riscv_enc::I(12'd3,  5'd0, 3'b000, 5'd2, ENC_OP_IMM), // x2=3
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b000, 5'd3, ENC_OP), // ADD
            riscv_enc::R(7'h20, 5'd2, 5'd1, 3'b000, 5'd4, ENC_OP), // SUB
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b111, 5'd5, ENC_OP), // AND
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b110, 5'd6, ENC_OP), // OR
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b100, 5'd7, ENC_OP), // XOR
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b001, 5'd8, ENC_OP)  // SLL
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_load_use_seq — Load-Use Hazard
// =============================================================================
class riscv_load_use_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_load_use_seq)

    function new(string name = "riscv_load_use_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "load_use";
        item.run_cycles = 25;
        item.check_mask = 32'hF << 1;  // x1..x4

        // Store 42 at addr 0 → LW x3 (load-use) → ADD x4=x3+x3
        item.program = '{
            riscv_enc::I(12'd42,  5'd0, 3'b000, 5'd1, ENC_OP_IMM),  // x1=42
            riscv_enc::S(12'd0,   5'd1, 5'd0, 3'b010),                      // SW x1,0(x0)
            ENC_NOP,
            riscv_enc::I(12'd0,   5'd0, 3'b010, 5'd3, ENC_LOAD),    // LW x3,0(x0)
            riscv_enc::R(7'h00, 5'd3, 5'd3, 3'b000, 5'd4, ENC_OP)   // ADD x4=x3+x3
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_branch_seq — Branch taken / not-taken
// =============================================================================
class riscv_branch_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_branch_seq)

    function new(string name = "riscv_branch_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "branch";
        item.run_cycles = 35;
        item.check_mask = 32'hFF << 1;

        // BEQ taken: x1==x2 → skip x3=99 → x4=x3+1=1
        // BNE taken: x5!=x6 → skip x7=99
        item.program = '{
            riscv_enc::I(12'd5,  5'd0, 3'b000, 5'd1, ENC_OP_IMM),  // PC=0: x1=5
            riscv_enc::I(12'd5,  5'd0, 3'b000, 5'd2, ENC_OP_IMM),  // PC=4: x2=5
            riscv_enc::B(13'd8,  5'd1, 5'd2,   3'b000),                    // PC=8: BEQ +8→PC16
            riscv_enc::I(12'd99, 5'd0, 3'b000, 5'd3, ENC_OP_IMM),  // PC=12: [SKIP]
            riscv_enc::I(12'd1,  5'd3, 3'b000, 5'd4, ENC_OP_IMM),  // PC=16: x4=x3+1
            riscv_enc::I(12'd3,  5'd0, 3'b000, 5'd5, ENC_OP_IMM),  // PC=20: x5=3
            riscv_enc::I(12'd7,  5'd0, 3'b000, 5'd6, ENC_OP_IMM),  // PC=24: x6=7
            riscv_enc::B(13'd8,  5'd5, 5'd6,   3'b001),                    // PC=28: BNE +8→36
            riscv_enc::I(12'd99, 5'd0, 3'b000, 5'd7, ENC_OP_IMM),  // PC=32: [SKIP]
            ENC_NOP                                                 // PC=36
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_fwd_chain_seq — 3-deep EX-EX Forwarding Chain
// =============================================================================
class riscv_fwd_chain_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_fwd_chain_seq)

    function new(string name = "riscv_fwd_chain_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "fwd_chain";
        item.run_cycles = 20;
        item.check_mask = 32'hF << 2;  // x2..x4

        // x1=4: x2=x1+1=5, x3=x2+1=6, x4=x3+1=7 (EX-EX fwd each step)
        item.program = '{
            riscv_enc::I(12'd4, 5'd0, 3'b000, 5'd1, ENC_OP_IMM), // x1=4
            riscv_enc::I(12'd1, 5'd1, 3'b000, 5'd2, ENC_OP_IMM), // x2=5
            riscv_enc::I(12'd1, 5'd2, 3'b000, 5'd3, ENC_OP_IMM), // x3=6
            riscv_enc::I(12'd1, 5'd3, 3'b000, 5'd4, ENC_OP_IMM)  // x4=7
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_loop_seq — Sum 1..10 (branch predictor warm-up)
// =============================================================================
class riscv_loop_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_loop_seq)

    function new(string name = "riscv_loop_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "loop";
        item.run_cycles = 100;
        item.check_mask = 32'h1 << 1;  // check x1 (sum)

        // x1=sum=0, x2=i=1, x3=10
        // loop: x1+=x2; x2++; BGE x3,x2 → loop
        // → x1 = 55
        item.program = '{
            riscv_enc::I(12'd0,  5'd0, 3'b000, 5'd1, ENC_OP_IMM), // x1=0
            riscv_enc::I(12'd1,  5'd0, 3'b000, 5'd2, ENC_OP_IMM), // x2=1
            riscv_enc::I(12'd10, 5'd0, 3'b000, 5'd3, ENC_OP_IMM), // x3=10
            riscv_enc::R(7'h00, 5'd2, 5'd1, 3'b000, 5'd1, ENC_OP), // x1+=x2
            riscv_enc::I(12'd1, 5'd2, 3'b000, 5'd2, ENC_OP_IMM),   // x2++
            riscv_enc::B(13'h1FF8, 5'd3, 5'd2, 3'b101)                    // BGE x3,x2,-8
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_jal_seq — JAL unconditional jump + link
// =============================================================================
class riscv_jal_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_jal_seq)

    function new(string name = "riscv_jal_seq");
        super.new(name);
    endfunction

    task body();
        riscv_seq_item item = riscv_seq_item::type_id::create("item");
        start_item(item);

        item.tag        = "jal";
        item.run_cycles = 20;
        item.check_mask = 32'h7 << 1;  // x1, x2, x3(=x5 at target)

        // PC=0: x5=7; PC=4: JAL x1,+8→PC12; PC=8:[skip x6=99]; PC=12: x7=x5
        item.program = '{
            riscv_enc::I(12'd7,  5'd0, 3'b000, 5'd5, ENC_OP_IMM), // PC=0: x5=7
            riscv_enc::J(21'd8,  5'd1),                                    // PC=4: JAL x1,+8
            riscv_enc::I(12'd99, 5'd0, 3'b000, 5'd6, ENC_OP_IMM), // PC=8: [SKIP]
            riscv_enc::I(12'd0,  5'd5, 3'b000, 5'd7, ENC_OP_IMM)  // PC=12: x7=x5
        };

        finish_item(item);
    endtask

endclass

// =============================================================================
// riscv_all_seq — Runs all 6 sequences back-to-back
// =============================================================================
class riscv_all_seq extends uvm_sequence #(riscv_seq_item);

    `uvm_object_utils(riscv_all_seq)

    function new(string name = "riscv_all_seq");
        super.new(name);
    endfunction

    task body();
        riscv_rtype_seq    s_rtype    = riscv_rtype_seq::type_id::create("s_rtype");
        riscv_load_use_seq s_load_use = riscv_load_use_seq::type_id::create("s_load_use");
        riscv_branch_seq   s_branch   = riscv_branch_seq::type_id::create("s_branch");
        riscv_fwd_chain_seq s_fwd     = riscv_fwd_chain_seq::type_id::create("s_fwd");
        riscv_loop_seq     s_loop     = riscv_loop_seq::type_id::create("s_loop");
        riscv_jal_seq      s_jal      = riscv_jal_seq::type_id::create("s_jal");

        s_rtype.start(m_sequencer);
        s_load_use.start(m_sequencer);
        s_branch.start(m_sequencer);
        s_fwd.start(m_sequencer);
        s_loop.start(m_sequencer);
        s_jal.start(m_sequencer);
    endtask

endclass

`endif // RISCV_SEQUENCES_SV
