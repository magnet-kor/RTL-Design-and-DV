// =============================================================================
// riscv_driver.sv — UVM Driver
// =============================================================================
// For each sequence item:
//   1. Backdoor-deposit instruction words into DUT imem
//   2. Clear dmem (isolation between tests)
//   3. Assert / de-assert rst_n
//   4. Wait run_cycles after reset release
//   5. Indicate completion via ap_done analysis port
// =============================================================================

`ifndef RISCV_DRIVER_SV
`define RISCV_DRIVER_SV

class riscv_driver extends uvm_driver #(riscv_seq_item);

    `uvm_component_utils(riscv_driver)

    // Virtual interface handle
    virtual riscv_if.driver_mp vif;

    // HDL root path for backdoor access (e.g. "tb_top.dut")
    string hdl_root;

    // Analysis port: notifies monitor that the run window is complete
    uvm_analysis_port #(riscv_seq_item) ap_done;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        ap_done = new("ap_done", this);

        if (!uvm_config_db #(virtual riscv_if)::get(this, "", "vif", vif))
            `uvm_fatal("CFG", "riscv_if not found in config_db")

        if (!uvm_config_db #(string)::get(this, "", "hdl_root", hdl_root))
            hdl_root = "tb_top.dut";  // sensible default
    endfunction

    task run_phase(uvm_phase phase);
        riscv_seq_item item;

        // Ensure DUT starts in reset
        vif.cb_driver.rst_n <= 1'b0;
        @(vif.cb_driver);

        forever begin
            seq_item_port.get_next_item(item);
            drive_item(item);
            seq_item_port.item_done();
        end
    endtask

    // ── Drive one transaction ─────────────────────────────────
    task automatic drive_item(riscv_seq_item item);
        `uvm_info("DRV", $sformatf("Driving: %s", item.convert2string()), UVM_MEDIUM)

        // 1. Backdoor-load imem
        load_imem(item.program);

        // 2. Clear dmem for test isolation
        clear_dmem();

        // 3. Assert reset for 3 cycles
        vif.cb_driver.rst_n <= 1'b0;
        repeat(3) @(vif.cb_driver);

        // 4. Release reset
        vif.cb_driver.rst_n <= 1'b1;
        @(vif.cb_driver);

        // 5. Run for the specified number of cycles
        repeat(item.run_cycles) @(vif.cb_driver);

        // 6. Notify monitor via analysis port
        ap_done.write(item);
    endtask

    // ── Backdoor: deposit program words into DUT imem ─────────
    function automatic void load_imem(logic [31:0] prog []);
        string path;
        // Fill with NOP first
        for (int i = 0; i < 1024; i++) begin
            path = $sformatf("%s.imem[%0d]", hdl_root, i);
            void'(uvm_hdl_deposit(path, 32'h0000_0013));
        end
        // Load program words
        foreach (prog[i]) begin
            path = $sformatf("%s.imem[%0d]", hdl_root, i);
            if (!uvm_hdl_deposit(path, prog[i]))
                `uvm_error("DRV", $sformatf("uvm_hdl_deposit failed: %s", path))
        end
    endfunction

    // ── Backdoor: zero out data memory ────────────────────────
    function automatic void clear_dmem();
        string path;
        for (int i = 0; i < 1024; i++) begin
            path = $sformatf("%s.dmem[%0d]", hdl_root, i);
            void'(uvm_hdl_deposit(path, 32'b0));
        end
    endfunction

endclass : riscv_driver

`endif // RISCV_DRIVER_SV
