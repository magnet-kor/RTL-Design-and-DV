// =============================================================================
// riscv_agent.sv — UVM Agent
// =============================================================================
`ifndef RISCV_AGENT_SV
`define RISCV_AGENT_SV

class riscv_agent extends uvm_agent;

    `uvm_component_utils(riscv_agent)

    typedef uvm_sequencer #(riscv_seq_item) riscv_sequencer_t;

    riscv_sequencer_t sequencer;
    riscv_driver      driver;
    riscv_monitor     monitor;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        sequencer = riscv_sequencer_t::type_id::create("sequencer", this);
        driver    = riscv_driver::type_id::create("driver",    this);
        monitor   = riscv_monitor::type_id::create("monitor",  this);
    endfunction

    function void connect_phase(uvm_phase phase);
        // Driver ← Sequencer
        driver.seq_item_port.connect(sequencer.seq_item_export);

        // Driver → Monitor (ap_done → fifo_done)
        driver.ap_done.connect(monitor.fifo_done.analysis_export);
    endfunction

endclass : riscv_agent

`endif // RISCV_AGENT_SV


// =============================================================================
// riscv_env.sv — UVM Environment
// =============================================================================
`ifndef RISCV_ENV_SV
`define RISCV_ENV_SV

class riscv_env extends uvm_env;

    `uvm_component_utils(riscv_env)

    riscv_agent      agent;
    riscv_scoreboard scoreboard;
    riscv_coverage   coverage;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        agent      = riscv_agent::type_id::create("agent",      this);
        scoreboard = riscv_scoreboard::type_id::create("scoreboard", this);
        coverage   = riscv_coverage::type_id::create("coverage", this);
    endfunction

    function void connect_phase(uvm_phase phase);
        // Monitor → Scoreboard
        agent.monitor.ap_sb.connect(scoreboard.ap);

        // Monitor → Coverage
        agent.monitor.ap_cov.connect(coverage.analysis_export);
    endfunction

endclass : riscv_env

`endif // RISCV_ENV_SV
