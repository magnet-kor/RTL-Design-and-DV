// =============================================================================
// riscv_if.sv — Virtual Interface for RISC-V Pipeline CPU Testbench
// =============================================================================
// Bundles all signals needed for:
//   - Clock/reset drive (clocking block cb_driver)
//   - DUT observation (clocking block cb_monitor)
//
// Backdoor paths for imem/dmem/regfile are accessed via
// uvm_hdl_read / uvm_hdl_deposit in the driver and monitor.
// The HDL path root is passed through uvm_config_db.
// =============================================================================

interface riscv_if (input logic clk);

    logic rst_n;

    // ── Driver clocking block ─────────────────────────────────
    // All driver output signals are synchronised on the rising edge.
    clocking cb_driver @(posedge clk);
        default input #1step output #1;
        output rst_n;
    endclocking

    // ── Monitor clocking block ────────────────────────────────
    // Monitor samples one step before the rising edge to avoid races.
    clocking cb_monitor @(posedge clk);
        default input #1step;
        input rst_n;
    endclocking

    // ── Modport declarations ──────────────────────────────────
    modport driver_mp  (clocking cb_driver,  input clk);
    modport monitor_mp (clocking cb_monitor, input clk);

endinterface : riscv_if
