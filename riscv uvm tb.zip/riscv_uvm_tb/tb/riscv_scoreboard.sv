// =============================================================================
// riscv_scoreboard.sv — UVM Scoreboard
// =============================================================================
// Receives observed transactions from the monitor.
// Runs the ISA reference model on the same program to compute exp_regs.
// Compares obs_regs[r] vs exp_regs[r] for every bit set in check_mask.
// =============================================================================

`ifndef RISCV_SCOREBOARD_SV
`define RISCV_SCOREBOARD_SV

class riscv_scoreboard extends uvm_scoreboard;

    `uvm_component_utils(riscv_scoreboard)

    // Receive observations from monitor
    uvm_analysis_imp #(riscv_seq_item, riscv_scoreboard) ap;

    // Counters
    int unsigned pass_cnt;
    int unsigned fail_cnt;
    int unsigned test_cnt;

    // Reference model instance
    riscv_isa_model ref_model;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        pass_cnt = 0;
        fail_cnt = 0;
        test_cnt = 0;
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        ap        = new("ap", this);
        ref_model = riscv_isa_model::type_id::create("ref_model");
    endfunction

    // ── Write callback: called by monitor ─────────────────────
    function void write(riscv_seq_item item);
        test_cnt++;
        check_item(item);
    endfunction

    // ── Run reference model and compare ───────────────────────
    function automatic void check_item(riscv_seq_item item);
        logic [31:0] exp_val, obs_val;

        // Run ISA model on the same program
        ref_model.load_program(item.program);
        ref_model.run(item.run_cycles * 2);  // give ref extra headroom

        `uvm_info("SB",
            $sformatf("=== [%s] Checking (run=%0d cyc) ===",
                      item.tag, item.run_cycles),
            UVM_LOW)

        for (int r = 0; r < 32; r++) begin
            if (!item.check_mask[r]) continue;

            obs_val = item.obs_regs[r];
            exp_val = ref_model.regs[r];

            if (obs_val === exp_val) begin
                pass_cnt++;
                `uvm_info("SB",
                    $sformatf("  PASS  x%-2d  obs=0x%08x  exp=0x%08x",
                              r, obs_val, exp_val),
                    UVM_MEDIUM)
            end else begin
                fail_cnt++;
                `uvm_error("SB",
                    $sformatf("  FAIL  x%-2d  obs=0x%08x  exp=0x%08x  [%s]",
                              r, obs_val, exp_val, item.tag))
            end
        end
    endfunction

    function void report_phase(uvm_phase phase);
        `uvm_info("SB", "==========================================", UVM_NONE)
        `uvm_info("SB",
            $sformatf("  Tests: %0d   PASS: %0d   FAIL: %0d",
                      test_cnt, pass_cnt, fail_cnt),
            UVM_NONE)
        if (fail_cnt == 0)
            `uvm_info("SB",  "  ALL CHECKS PASSED", UVM_NONE)
        else
            `uvm_fatal("SB", "  FAILURES DETECTED — simulation FAILED")
        `uvm_info("SB", "==========================================", UVM_NONE)
    endfunction

endclass : riscv_scoreboard

`endif // RISCV_SCOREBOARD_SV
