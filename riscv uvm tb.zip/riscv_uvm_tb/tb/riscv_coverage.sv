// =============================================================================
// riscv_coverage.sv — Functional Coverage Collector
// =============================================================================
// Coverage groups:
//   cg_opcode  : Was each major opcode group exercised?
//   cg_hazard  : Were all pipeline hazard scenarios hit?
//   cg_branch  : Branch taken vs not-taken cross coverage
//
// All coverpoints are sampled once per completed sequence item.
// =============================================================================

`ifndef RISCV_COVERAGE_SV
`define RISCV_COVERAGE_SV

class riscv_coverage extends uvm_subscriber #(riscv_seq_item);

    `uvm_component_utils(riscv_coverage)

    riscv_seq_item item;

    // ── Internal analysis of the program ─────────────────────
    // Set by sample() to describe what the current program contains
    bit has_rtype;
    bit has_itype;
    bit has_load;
    bit has_store;
    bit has_branch;
    bit has_jal;
    bit has_load_use;    // LW immediately followed by dependent ALU
    bit has_fwd_chain;   // ≥3 consecutive dependent instructions

    // ── Covergroups ───────────────────────────────────────────

    // Opcode-class coverage
    covergroup cg_opcode;
        cp_rtype:  coverpoint has_rtype  { bins hit = {1}; }
        cp_itype:  coverpoint has_itype  { bins hit = {1}; }
        cp_load:   coverpoint has_load   { bins hit = {1}; }
        cp_store:  coverpoint has_store  { bins hit = {1}; }
        cp_branch: coverpoint has_branch { bins hit = {1}; }
        cp_jal:    coverpoint has_jal    { bins hit = {1}; }

        // At least 3 opcode classes per test
        cross cp_rtype, cp_itype, cp_load;
    endgroup

    // Hazard coverage
    covergroup cg_hazard;
        cp_load_use:  coverpoint has_load_use  { bins hit = {1}; bins miss = {0}; }
        cp_fwd_chain: coverpoint has_fwd_chain { bins hit = {1}; bins miss = {0}; }
        cross cp_load_use, cp_fwd_chain;
    endgroup

    // Branch outcome coverage
    covergroup cg_branch_outcome;
        cp_taken:     coverpoint has_branch { bins with_branch = {1}; }
        // Drill down by sequence tag (taken vs not-taken tests)
        cp_tag: coverpoint item.tag {
            bins rtype    = {"rtype"};
            bins branch   = {"branch"};
            bins loop     = {"loop"};
            bins loaduse  = {"load_use"};
            bins fwdchain = {"fwd_chain"};
            bins jal_test = {"jal"};
        }
    endgroup

    function new(string name, uvm_component parent);
        super.new(name, parent);
        cg_opcode         = new();
        cg_hazard         = new();
        cg_branch_outcome = new();
    endfunction

    // ── write(): called by monitor via uvm_subscriber ─────────
    function void write(riscv_seq_item t);
        item = t;
        analyse_program(t.program);
        cg_opcode.sample();
        cg_hazard.sample();
        cg_branch_outcome.sample();
    endfunction

    // ── Scan the program to set hazard/opcode flags ───────────
    function automatic void analyse_program(logic [31:0] prog []);
        has_rtype     = 0;
        has_itype     = 0;
        has_load      = 0;
        has_store     = 0;
        has_branch    = 0;
        has_jal       = 0;
        has_load_use  = 0;
        has_fwd_chain = 0;

        foreach (prog[i]) begin
            logic [6:0] opc = prog[i][6:0];
            logic [4:0] rd  = prog[i][11:7];

            case (opc)
                7'b0110011: has_rtype  = 1;
                7'b0010011: has_itype  = 1;
                7'b0000011: has_load   = 1;
                7'b0100011: has_store  = 1;
                7'b1100011: has_branch = 1;
                7'b1101111: has_jal    = 1;
            endcase

            // Load-use: LW at i, next instr reads same rd as rs1 or rs2
            if (opc == 7'b0000011 && i+1 < prog.size()) begin
                logic [4:0] next_rs1 = prog[i+1][19:15];
                logic [4:0] next_rs2 = prog[i+1][24:20];
                if (rd != 5'b0 && (rd == next_rs1 || rd == next_rs2))
                    has_load_use = 1;
            end

            // Forwarding chain: 3 consecutive RAW dependencies
            if (i+2 < prog.size()) begin
                logic [4:0] rd0  = prog[i  ][11:7];
                logic [4:0] rs1_1 = prog[i+1][19:15];
                logic [4:0] rd1  = prog[i+1][11:7];
                logic [4:0] rs1_2 = prog[i+2][19:15];
                if (rd0 != 0 && rd0 == rs1_1 &&
                    rd1 != 0 && rd1 == rs1_2)
                    has_fwd_chain = 1;
            end
        end
    endfunction

    function void report_phase(uvm_phase phase);
        `uvm_info("COV",
            $sformatf("Opcode coverage:  %.1f%%", cg_opcode.get_coverage()),
            UVM_NONE)
        `uvm_info("COV",
            $sformatf("Hazard coverage:  %.1f%%", cg_hazard.get_coverage()),
            UVM_NONE)
        `uvm_info("COV",
            $sformatf("Branch coverage:  %.1f%%", cg_branch_outcome.get_coverage()),
            UVM_NONE)
    endfunction

endclass : riscv_coverage

`endif // RISCV_COVERAGE_SV
