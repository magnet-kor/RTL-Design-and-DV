// =============================================================================
// riscv_isa_model.sv — RV32I ISA Reference Model
// =============================================================================
// Pure-software instruction-accurate model.
// Used by the scoreboard to compute expected register values
// independently of the RTL pipeline.
//
// Supported: R-type, I-type (ALU + load), S-type (store), B-type,
//            LUI, AUIPC, JAL, JALR
//
// Execution terminates when PC passes program boundary (NOP slide).
// =============================================================================

`ifndef RISCV_ISA_MODEL_SV
`define RISCV_ISA_MODEL_SV

class riscv_isa_model extends uvm_object;

    `uvm_object_utils(riscv_isa_model)

    // Architectural state
    logic [31:0] regs [32];
    logic [31:0] mem  [1024];  // word-addressed
    logic [31:0] pc;

    // Execution statistics (for coverage feedback)
    int unsigned instr_count;
    int unsigned branch_taken_cnt;
    int unsigned branch_not_taken_cnt;
    int unsigned load_use_cnt;

    function new(string name = "riscv_isa_model");
        super.new(name);
    endfunction

    // ── Reset ─────────────────────────────────────────────────
    function void reset();
        foreach (regs[i]) regs[i] = 32'b0;
        foreach (mem[i])  mem[i]  = 32'b0;
        pc           = 32'b0;
        instr_count  = 0;
        branch_taken_cnt     = 0;
        branch_not_taken_cnt = 0;
        load_use_cnt = 0;
    endfunction

    // ── Load program ──────────────────────────────────────────
    function void load_program(logic [31:0] prog []);
        reset();
        foreach (prog[i]) mem[i] = prog[i];
        // Pad with NOP (ADDI x0,x0,0)
        for (int i = prog.size(); i < 1024; i++)
            mem[i] = 32'h0000_0013;
    endfunction

    // ── Run for max_cycles steps ──────────────────────────────
    // Returns when PC leaves the loaded program area or max_steps reached.
    function void run(int max_steps = 200);
        int steps = 0;
        while (steps < max_steps) begin
            logic [31:0] instr;
            instr = mem[pc[31:2]];
            if (!execute(instr)) break;
            steps++;
            instr_count++;
        end
    endfunction

    // ── Execute one instruction; returns 1 to continue, 0 to halt ──
    function automatic bit execute(logic [31:0] instr);
        logic [6:0]  opcode = instr[6:0];
        logic [4:0]  rd     = instr[11:7];
        logic [2:0]  f3     = instr[14:12];
        logic [4:0]  rs1    = instr[19:15];
        logic [4:0]  rs2    = instr[24:20];
        logic [6:0]  f7     = instr[31:25];

        // Immediate decode (sign-extended)
        logic [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
        imm_i = {{20{instr[31]}}, instr[31:20]};
        imm_s = {{20{instr[31]}}, instr[31:25], instr[11:7]};
        imm_b = {{19{instr[31]}}, instr[31], instr[7],
                 instr[30:25], instr[11:8], 1'b0};
        imm_u = {instr[31:12], 12'b0};
        imm_j = {{11{instr[31]}}, instr[31], instr[19:12],
                 instr[20], instr[30:21], 1'b0};

        logic [31:0] rv1 = (rs1 == 5'b0) ? 32'b0 : regs[rs1];
        logic [31:0] rv2 = (rs2 == 5'b0) ? 32'b0 : regs[rs2];
        logic [31:0] result;
        logic [31:0] next_pc = pc + 32'd4;

        case (opcode)
            // ── R-type ───────────────────────────────────────
            7'b0110011: begin
                case ({f7[5], f3})
                    4'b0_000: result = rv1 + rv2;          // ADD
                    4'b1_000: result = rv1 - rv2;          // SUB
                    4'b0_001: result = rv1 << rv2[4:0];    // SLL
                    4'b0_010: result = ($signed(rv1) < $signed(rv2)) ? 32'd1 : 32'd0; // SLT
                    4'b0_011: result = (rv1 < rv2) ? 32'd1 : 32'd0;  // SLTU
                    4'b0_100: result = rv1 ^ rv2;          // XOR
                    4'b0_101: result = rv1 >> rv2[4:0];    // SRL
                    4'b1_101: result = $signed(rv1) >>> rv2[4:0]; // SRA
                    4'b0_110: result = rv1 | rv2;          // OR
                    4'b0_111: result = rv1 & rv2;          // AND
                    default:  result = 32'b0;
                endcase
                if (rd != 5'b0) regs[rd] = result;
            end

            // ── I-type ALU ────────────────────────────────────
            7'b0010011: begin
                case (f3)
                    3'b000: result = rv1 + imm_i;          // ADDI
                    3'b001: result = rv1 << imm_i[4:0];    // SLLI
                    3'b010: result = ($signed(rv1) < $signed(imm_i)) ? 32'd1 : 32'd0; // SLTI
                    3'b011: result = (rv1 < imm_i) ? 32'd1 : 32'd0;  // SLTIU
                    3'b100: result = rv1 ^ imm_i;          // XORI
                    3'b101: result = (f7[5]) ? ($signed(rv1) >>> imm_i[4:0])  // SRAI
                                             : (rv1 >> imm_i[4:0]);           // SRLI
                    3'b110: result = rv1 | imm_i;          // ORI
                    3'b111: result = rv1 & imm_i;          // ANDI
                    default: result = 32'b0;
                endcase
                if (rd != 5'b0) regs[rd] = result;
            end

            // ── Load ─────────────────────────────────────────
            7'b0000011: begin
                logic [31:0] addr = rv1 + imm_i;
                logic [31:0] raw  = mem[addr[31:2]];
                case (f3)
                    3'b000: result = {{24{raw[7]}},  raw[7:0]};   // LB
                    3'b001: result = {{16{raw[15]}}, raw[15:0]};  // LH
                    3'b010: result = raw;                          // LW
                    3'b100: result = {24'b0, raw[7:0]};           // LBU
                    3'b101: result = {16'b0, raw[15:0]};          // LHU
                    default: result = raw;
                endcase
                if (rd != 5'b0) regs[rd] = result;
            end

            // ── Store ─────────────────────────────────────────
            7'b0100011: begin
                logic [31:0] addr = rv1 + imm_s;
                case (f3)
                    3'b000: mem[addr[31:2]][7:0]  = rv2[7:0];   // SB
                    3'b001: mem[addr[31:2]][15:0] = rv2[15:0];  // SH
                    3'b010: mem[addr[31:2]]        = rv2;        // SW
                endcase
            end

            // ── Branch ────────────────────────────────────────
            7'b1100011: begin
                bit taken;
                case (f3)
                    3'b000: taken = (rv1 == rv2);                           // BEQ
                    3'b001: taken = (rv1 != rv2);                           // BNE
                    3'b100: taken = ($signed(rv1) < $signed(rv2));          // BLT
                    3'b101: taken = ($signed(rv1) >= $signed(rv2));         // BGE
                    3'b110: taken = (rv1 < rv2);                            // BLTU
                    3'b111: taken = (rv1 >= rv2);                           // BGEU
                    default: taken = 0;
                endcase
                if (taken) begin
                    next_pc = pc + imm_b;
                    branch_taken_cnt++;
                end else begin
                    branch_not_taken_cnt++;
                end
            end

            // ── JAL ───────────────────────────────────────────
            7'b1101111: begin
                if (rd != 5'b0) regs[rd] = pc + 32'd4;
                next_pc = pc + imm_j;
            end

            // ── JALR ─────────────────────────────────────────
            7'b1100111: begin
                logic [31:0] target = (rv1 + imm_i) & ~32'h1;
                if (rd != 5'b0) regs[rd] = pc + 32'd4;
                next_pc = target;
            end

            // ── LUI ───────────────────────────────────────────
            7'b0110111: begin
                if (rd != 5'b0) regs[rd] = imm_u;
            end

            // ── AUIPC ─────────────────────────────────────────
            7'b0010111: begin
                if (rd != 5'b0) regs[rd] = pc + imm_u;
            end

            // ── NOP / unimplemented → halt ────────────────────
            default: return 0;
        endcase

        regs[0] = 32'b0;  // x0 always zero
        pc = next_pc;
        return 1;
    endfunction

endclass : riscv_isa_model

`endif // RISCV_ISA_MODEL_SV
