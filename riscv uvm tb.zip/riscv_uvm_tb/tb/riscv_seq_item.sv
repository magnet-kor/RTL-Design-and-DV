// =============================================================================
// riscv_seq_item.sv — UVM Sequence Item (Transaction)
// =============================================================================
// Carries:
//   program[]    : instruction words to load into imem
//   run_cycles   : how long to run after reset release
//   check_mask   : which architectural registers to verify
//   exp_regs[]   : expected register values (filled by scoreboard ref model)
//   tag          : human-readable test name for reporting
//
// The driver loads program[] via backdoor (uvm_hdl_deposit),
// drives reset, then waits run_cycles.
// The monitor reads regfile via uvm_hdl_read after run_cycles.
// =============================================================================

`ifndef RISCV_SEQ_ITEM_SV
`define RISCV_SEQ_ITEM_SV

class riscv_seq_item extends uvm_sequence_item;

    `uvm_object_utils_begin(riscv_seq_item)
        `uvm_field_array_int(program,    UVM_ALL_ON)
        `uvm_field_int      (run_cycles, UVM_ALL_ON)
        `uvm_field_int      (check_mask, UVM_ALL_ON)
        `uvm_field_string   (tag,        UVM_ALL_ON)
    `uvm_object_utils_end

    // ── Stimulus ──────────────────────────────────────────────
    // Instruction words; max depth = IMEM_DEPTH (1024 in DUT)
    rand logic [31:0] program [];

    // Number of clock cycles to run after rst_n de-assertion
    rand int unsigned run_cycles;

    // Bitmask of registers to verify (bit N = 1 → check x[N])
    logic [31:0]      check_mask;

    // Human-readable scenario name
    string            tag;

    // ── Response (filled by scoreboard reference model) ───────
    // Expected architectural register values after run_cycles
    logic [31:0]      exp_regs [32];

    // Observed register values (filled by monitor)
    logic [31:0]      obs_regs [32];

    // ── Constraints ───────────────────────────────────────────
    constraint c_run_cycles {
        run_cycles inside {[15:120]};
    }
    constraint c_program_size {
        program.size() inside {[4:32]};
    }

    // ── Constructor ───────────────────────────────────────────
    function new(string name = "riscv_seq_item");
        super.new(name);
        check_mask = 32'b0;
        tag        = "unnamed";
        foreach (exp_regs[i]) exp_regs[i] = 32'b0;
        foreach (obs_regs[i]) obs_regs[i] = 32'b0;
    endfunction

    // ── Helpers ───────────────────────────────────────────────
    // Mark register r as a check target with expected value v
    function void expect_reg(int r, logic [31:0] v);
        if (r > 0 && r < 32) begin
            check_mask[r] = 1'b1;
            exp_regs[r]   = v;
        end
    endfunction

    function string convert2string();
        string s;
        s = $sformatf("[%s] prog_words=%0d run=%0d cycles",
                      tag, program.size(), run_cycles);
        return s;
    endfunction

endclass : riscv_seq_item

`endif // RISCV_SEQ_ITEM_SV
