// =============================================================================
// tb_top.sv — Testbench Top Level
// =============================================================================
// Instantiates:
//   - Clock generator
//   - riscv_if interface
//   - riscv_pipeline DUT
//   - UVM run_test() kickoff
//
// HDL backdoor paths expected by driver/monitor:
//   DUT imem:   tb_top.dut.imem[N]
//   DUT dmem:   tb_top.dut.dmem[N]
//   Reg file:   tb_top.dut.u_rf.regs[N]
//
// Usage:
//   vcs +UVM_TESTNAME=riscv_all_test
//   vsim tb_top +UVM_TESTNAME=riscv_rtype_test
// =============================================================================

`timescale 1ns/1ps

module tb_top;

    import uvm_pkg::*;
    `include "uvm_macros.svh"

    import riscv_tb_pkg::*;

    // ── Clock generator ───────────────────────────────────────
    // 10 ns period (100 MHz) — plenty of margin for back-annotation
    logic clk = 1'b0;
    always #5 clk = ~clk;

    // ── Interface ─────────────────────────────────────────────
    riscv_if rif (.clk(clk));

    // ── DUT ───────────────────────────────────────────────────
    riscv_pipeline dut (
        .clk   (clk),
        .rst_n (rif.rst_n)
    );

    // ── UVM setup ─────────────────────────────────────────────
    initial begin
        // Push interface into config_db so all components can get it
        uvm_config_db #(virtual riscv_if)::set(
            uvm_root::get(), "uvm_test_top.*", "vif", rif);

        // HDL root for backdoor access
        uvm_config_db #(string)::set(
            uvm_root::get(), "uvm_test_top.*", "hdl_root", "tb_top.dut");

        // Waveform dump (comment out for regression speed)
        $dumpfile("riscv_uvm.vcd");
        $dumpvars(0, tb_top);

        run_test();   // test name comes from +UVM_TESTNAME plusarg
    end

    // ── Timeout guard ─────────────────────────────────────────
    initial begin
        #500_000;
        `uvm_fatal("TIMEOUT", "Simulation exceeded 500 us")
    end

endmodule
