// =============================================================================
// riscv_tests.sv — UVM Test Classes
// =============================================================================
// Select via: +UVM_TESTNAME=<test_class>
//
//   riscv_rtype_test    R-type arithmetic only
//   riscv_load_use_test Load/store + load-use hazard
//   riscv_branch_test   Branch taken/not-taken
//   riscv_loop_test     Branch predictor + loop
//   riscv_all_test      All 6 sequences (regression)
// =============================================================================

`ifndef RISCV_TESTS_SV
`define RISCV_TESTS_SV

// ── Base test ─────────────────────────────────────────────────────────────────
class riscv_base_test extends uvm_test;

    `uvm_component_utils(riscv_base_test)

    riscv_env env;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env = riscv_env::type_id::create("env", this);

        // Pass HDL root path to all components
        uvm_config_db #(string)::set(this, "env.agent.*", "hdl_root", "tb_top.dut");
    endfunction

    task run_phase(uvm_phase phase);
        phase.raise_objection(this);
        run_sequences(phase);
        phase.drop_objection(this);
    endtask

    // Override in derived tests
    virtual task run_sequences(uvm_phase phase);
    endtask

endclass

// ── riscv_rtype_test ──────────────────────────────────────────────────────────
class riscv_rtype_test extends riscv_base_test;

    `uvm_component_utils(riscv_rtype_test)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_sequences(uvm_phase phase);
        riscv_rtype_seq seq = riscv_rtype_seq::type_id::create("seq");
        seq.start(env.agent.sequencer);
    endtask

endclass

// ── riscv_load_use_test ───────────────────────────────────────────────────────
class riscv_load_use_test extends riscv_base_test;

    `uvm_component_utils(riscv_load_use_test)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_sequences(uvm_phase phase);
        riscv_load_use_seq seq = riscv_load_use_seq::type_id::create("seq");
        seq.start(env.agent.sequencer);
    endtask

endclass

// ── riscv_branch_test ─────────────────────────────────────────────────────────
class riscv_branch_test extends riscv_base_test;

    `uvm_component_utils(riscv_branch_test)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_sequences(uvm_phase phase);
        riscv_branch_seq seq = riscv_branch_seq::type_id::create("seq");
        seq.start(env.agent.sequencer);
    endtask

endclass

// ── riscv_loop_test ───────────────────────────────────────────────────────────
class riscv_loop_test extends riscv_base_test;

    `uvm_component_utils(riscv_loop_test)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_sequences(uvm_phase phase);
        riscv_loop_seq seq = riscv_loop_seq::type_id::create("seq");
        seq.start(env.agent.sequencer);
    endtask

endclass

// ── riscv_all_test ────────────────────────────────────────────────────────────
// Full regression: runs all 6 sequences
class riscv_all_test extends riscv_base_test;

    `uvm_component_utils(riscv_all_test)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_sequences(uvm_phase phase);
        riscv_all_seq seq = riscv_all_seq::type_id::create("seq");
        seq.start(env.agent.sequencer);
    endtask

endclass

`endif // RISCV_TESTS_SV
